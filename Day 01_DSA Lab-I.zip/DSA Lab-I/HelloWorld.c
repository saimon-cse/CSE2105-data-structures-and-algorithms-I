//iostream: Header file that contains declarations of all the standard input/output library functions
//In C++, all the header files may or may not end with the �.h� extension unlike in C.
//Include the standard iostream file which
//import the entity of the std namespace into the current namespace of the program

#include <iostream>
using namespace std;

int main()
{
	cout << "Hello World";

	return 0;
}
