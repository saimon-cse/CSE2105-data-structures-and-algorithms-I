//input output

#include <iostream>
using namespace std;

int main()
{
	int age;

	cout << "Enter your age:";
	cin >> age;
	cout << "\nYour age is: " << age;

	return 0;
}
