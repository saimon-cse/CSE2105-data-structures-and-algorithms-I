//creating your own header file
//Write your own C++ code and save that file with �.h� extension

// Function to find the sum of two
// numbers passed

int sumOfTwoNumbers(int a, int b) { return (a + b); }
