#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main()
{
    signed char c;
    scanf("%c", &c);
    int x = c - '0';
    printf("%c", c);
    return 0;
}
